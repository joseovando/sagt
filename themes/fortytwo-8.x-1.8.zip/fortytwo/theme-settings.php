<?php

/**
 * @file
 * The theme settings functions.
 */

require_once dirname(__FILE__) . '/includes/fortytwo.inc';
require_once dirname(__FILE__) . '/includes/theme-settings-general.inc';
