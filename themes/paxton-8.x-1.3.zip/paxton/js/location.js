$ = jQuery.noConflict();
$('#googlemaps').gMap({
	maptype: 'ROADMAP',
	scrollwheel: false,
	zoom: 13,
	markers: [
		{
			address: 'Los Angeles, United States', // Your Adress Here
			html: '',
			popup: false,
		}

	],

});