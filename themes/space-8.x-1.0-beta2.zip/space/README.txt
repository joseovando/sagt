 _________
/   _____/__________    ____  ____
 \_____  \\____ \__  \ _/ ___\/ __ \
 /        \  |_> > __ \\  \__\  ___/
/_______  /   __(____  /\___  >___  >
        \/|__|       \/     \/    \/

 A theme that is out of this world!

-------------------------------------

Installation
------------
The fastest way to install the Space theme is to run (with Drush 7):

  drush dl space

This will place the Space theme in your themes directory.


Set Up
------
When enabling the theme on a new site you will see a few blocks covering the
main screen. The first thing you want to do is get everything out of the
Header Top region. Then place the main navigation block in the Main Menu region.

Block configuration can be found at /admin/structure/block.

Use the following regions to create a nice scrolling front page:
  Content 2 - Image Background
  Content 3 - Plain Background
  Content 4 - Image Background
  Content 5 - Plain Background
These regions are usually not used anywhere but the front page.

Updates
-------
As of the time of writing this, the theme is very new and will likely receive
many changes to the structure in the near future. I'll try my best not to move
anything around, but only enhance the fluidity and look of the theme.
