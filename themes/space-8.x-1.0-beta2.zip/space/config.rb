output_style = (environment == :development) ? :expanded : :compressed;
css_dir = 'css'
sass_dir = 'scss'
images_dir = 'images'
javascripts_dir = 'js'
fonts_dir = 'fonts'
relative_assets = true
line_comments = true
add_import_path 'overrides'
